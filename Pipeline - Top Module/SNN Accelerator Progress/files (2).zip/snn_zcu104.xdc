##############################################################################
## snn_zcu104.xdc  –  ZCU104 (XCZU7EV-2FFVC1156) SNN Accelerator
## Clock: 200 MHz on PL fabric
##############################################################################

# ── Primary clock ────────────────────────────────────────────────────────────
# ZCU104 has a 125 MHz oscillator on SI5341 (U23) connected to the PL.
# Use MMCM to generate 200 MHz. Reference this generated clock here.
# Adjust get_ports name to match your MMCM output net name.
create_clock -period 5.000 -name clk_200m [get_ports clk_200m]

# ── Input timing (AER, from off-chip cochlea or GPIO) ────────────────────────
# Assume AER data is synchronous to clk_200m (re-synchronised in FIFO).
# If async, set false path and rely on the fifo_cdc to handle it.
set_input_delay  -clock clk_200m -max 2.0 [get_ports {aer_data[*] aer_valid}]
set_input_delay  -clock clk_200m -min 0.5 [get_ports {aer_data[*] aer_valid}]
set_input_delay  -clock clk_200m -max 2.0 [get_ports speech_valid]
set_input_delay  -clock clk_200m -min 0.5 [get_ports speech_valid]

# ── Output timing ─────────────────────────────────────────────────────────────
set_output_delay -clock clk_200m -max 2.0 [get_ports {cmd_id[*] confidence[*] result_valid window_ready}]
set_output_delay -clock clk_200m -min 0.0 [get_ports {cmd_id[*] confidence[*] result_valid window_ready}]

# ── Reset: async assert / sync de-assert handled in fabric ────────────────────
# If rst_n comes from PS or MMCM locked, set false path for async assertion.
set_false_path -from [get_ports rst_n]

# ── Timing exceptions for the argmax tree in overlap_voter ───────────────────
# The combinational path: score_N_reg → adder → argmax tree → pred_class_reg
# is ~4-5 ns at 200 MHz. If Vivado cannot close timing, enable multicycle:
# set_multicycle_path -setup 2 \
#     -from [get_cells -hier -filter {NAME =~ *u_output*score_N*}] \
#     -to   [get_cells -hier -filter {NAME =~ *u_output*ax_best*}]
# set_multicycle_path -hold  1 \
#     -from [get_cells -hier -filter {NAME =~ *u_output*score_N*}] \
#     -to   [get_cells -hier -filter {NAME =~ *u_output*ax_best*}]

# ── DSP inference ─────────────────────────────────────────────────────────────
# MAC accumulations should map to DSP58E2. Confirm in impl report.
# If Vivado does not infer DSPs automatically for h_acc additions, add:
# set_property USE_DSP yes [get_cells -hier -filter {NAME =~ *u_mac*h_acc*}]

# ── BRAM placement ─────────────────────────────────────────────────────────────
# Optional: place BRAMs near the MAC logic for minimum routing delay.
# Adjust RAMB location to your floorplan.
# set_property LOC RAMB36_X1Y8 [get_cells u_bram_weights]
# set_property LOC RAMB18_X1Y8 [get_cells u_bram_vm]

# ── Overlap voter shreg extract prevention ────────────────────────────────────
# Already set in RTL with (* shreg_extract = "no" *) attributes.
# Redundant constraint here, but belt-and-suspenders:
set_property SHREG_EXTRACT no \
    [get_cells -hier -filter {NAME =~ *u_output*score_N*}]
set_property SHREG_EXTRACT no \
    [get_cells -hier -filter {NAME =~ *u_output*score_Np1*}]
