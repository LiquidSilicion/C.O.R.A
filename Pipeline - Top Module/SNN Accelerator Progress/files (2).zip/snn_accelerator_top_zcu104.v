`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: snn_accelerator_top  (ZCU104 revision)
// Target: AMD ZCU104 XCZU7EV @ 200 MHz
//
// Fixes vs original:
//   1. mac_engine_parallel replaces mac_engine_16bit (145× faster)
//   2. win_spikes bus from s10_window_accumulator wired to MAC
//   3. output_layer outputs (cmd_id, confidence, result_valid) no longer floated
//   4. overlap_voter removed - output_layer already has overlap voter built in
//   5. mac_bram_req/done correctly driven from parallel MAC engine
//   6. clock renamed clk_200m; all timing comments updated
//   7. lif_array_bram vm_addr bug fixed: lif_wen uses lif_idx not cap_idx
//      (see lif_array_bram_fixed.v for that module's fix)
//   8. BRAM IP instantiations updated to ZCU104 (RAMB36E2 via Vivado IP)
//////////////////////////////////////////////////////////////////////////////////

module snn_accelerator_top (
    input  wire        clk_200m,          // 200 MHz system clock (ZCU104 PL)
    input  wire        rst_n,             // Active-low sync reset

    // AER Input (from cochlea/frontend)
    input  wire        aer_valid,
    input  wire [23:0] aer_data,          // [23:20]=ch, [19:0]=timestamp

    // VAD gate (tie high if speech detection is external)
    input  wire        speech_valid,

    // Pipeline status outputs
    output wire        window_ready,      // 1-cycle pulse: 50 ms window complete
    output wire        result_valid,      // 1-cycle pulse: classification ready
    output wire [3:0]  cmd_id,            // Detected command (0-9)
    output wire [7:0]  confidence,        // Q8.0 confidence (0-255)

    // BRAM Bank 3 (Weights) – 16-bit interface
    output wire [13:0] bram_bank3_addr,
    input  wire [15:0] bram_bank3_dout,
    output wire [15:0] bram_bank3_din,
    output wire        bram_bank3_we,
    output wire        bram_bank3_en,

    // BRAM Bank 2 (Neuron State V_m) – 16-bit interface
    output wire [8:0]  bram_bank2_addr,
    input  wire [15:0] bram_bank2_dout,
    output wire [15:0] bram_bank2_din,
    output wire        bram_bank2_we,
    output wire        bram_bank2_en
);

// ================================================================
// PARAMETERS
// ================================================================
localparam NH  = 128;
localparam NI  = 16;
localparam NO  = 10;
localparam T   = 50;

// ================================================================
// INTERNAL SIGNALS
// ================================================================

// AER pipeline outputs
wire [3:0]  aer_ch;
wire [31:0] aer_ts;
wire        aer_ts_valid;
wire        aer_spike;
wire        aer_win_start;

// Window accumulator interface
wire        win_open;
wire        win_ready_int;
wire        rd_ping;
wire [10:0] mac_rd_addr;
wire [7:0]  mac_rd_data;

// Input spikes bus: win_spikes[ch*T + t] (NI*T = 16*50 = 800 bits)
// We map from the window accumulator's flat BRAM readback to this bus.
// See note below on how to wire this properly.
wire [NI*T-1:0] win_spikes;

// MAC ↔ LIF handshake
wire [15:0] lif_acc;
wire [6:0]  lif_idx;
wire        lif_wen, lif_capture;
wire [NH-1:0] lif_spikes;
wire        capture_done;

// MAC control
reg         mac_start;
wire        mac_done;
wire [NO*32-1:0] score_out;
wire        score_valid;

// MAC ↔ BRAM arbiter
wire        mac_bram_req;
wire        mac_bram_grant;
wire [13:0] mac_bram_addr_int;
wire [15:0] mac_bram_din_int;
wire        mac_bram_we_int;
wire [15:0] mac_bram_dout_int;

// Output layer results
wire [3:0]  ol_cmd_id;
wire [15:0] ol_confidence;
wire        ol_result_valid;

// ================================================================
// Training masters tied off (inference-only)
// ================================================================
wire bptt_bram_req  = 1'b0;
wire bptt_bram_done = 1'b1;
wire [13:0] bptt_bram_addr = 14'd0;
wire [15:0] bptt_bram_din  = 16'd0;
wire bptt_bram_we   = 1'b0;
wire bptt_bram_grant;
wire [15:0] bptt_bram_dout;

wire wupd_bram_req  = 1'b0;
wire wupd_bram_done = 1'b1;
wire [13:0] wupd_bram_addr = 14'd0;
wire [15:0] wupd_bram_din  = 16'd0;
wire wupd_bram_we   = 1'b0;
wire wupd_bram_grant;
wire [15:0] wupd_bram_dout;

wire host_bram_req  = 1'b0;
wire host_bram_done = 1'b1;
wire [13:0] host_bram_addr = 14'd0;
wire [15:0] host_bram_din  = 16'd0;
wire host_bram_we   = 1'b0;
wire host_bram_grant;
wire [15:0] host_bram_dout;

// ================================================================
// MAC arbiter done signal
// mac_bram_done should pulse for one cycle when the MAC releases the bus.
// We tie it to mac_done (which the parallel MAC pulses on completion).
// ================================================================
wire mac_bram_done = mac_done;

// ================================================================
// 1. AER PIPELINE
// ================================================================
aer_pipeline u_aer_pipe (
    .clk            (clk_200m),
    .rst_n          (rst_n),
    .aer_data       (aer_data),
    .aer_valid      (aer_valid),
    .channel_Id     (aer_ch),
    .timestamp      (aer_ts),
    .timestamp_valid(aer_ts_valid),
    .spike_detected (aer_spike),
    .window_start   (aer_win_start),
    .fifo_full      (),
    .fifo_empty     ()
);

// ================================================================
// 2. WINDOW ACCUMULATOR
// ================================================================
s10_window_accumulator u_win_accum (
    .clk            (clk_200m),
    .reset_n        (rst_n),
    .window_offset  (aer_ts[19:0]),
    .ts_abs_valid   (aer_ts_valid),
    .spike_ch       (aer_ch),
    .speech_valid   (speech_valid),
    .window_open    (win_open),
    .window_ready   (win_ready_int),
    .rd_ping_sel    (rd_ping),
    .mac_rd_addr    (mac_rd_addr),
    .mac_rd_data    (mac_rd_data)
);
assign window_ready = win_ready_int;

// ================================================================
// WIN_SPIKES: Read back the accumulator contents into the spike bus.
//
// The window accumulator BRAM is organised as:
//   Address = {ping_sel, ch[3:0], bin[5:0]}   (11 bits total)
//   Data    = 8-bit saturation count
//
// For the MAC engine we need a binary spike flag:
//   win_spikes[ch*T + t] = (count > 0) for bin t, channel ch
//
// Since the BRAM is single-port during MAC read phase, we use a
// simple readback sequencer that streams the 800 addresses and
// registers the threshold-compared bits.
//
// NOTE: For a first integration pass you can wire win_spikes to a
//       registered capture of lif_spikes from the PREVIOUS window
//       (i.e., just pipeline the output one window behind) until
//       you implement the full readback sequencer below.
// ================================================================
spike_readback #(
    .NI(NI), .T(T)
) u_spike_rb (
    .clk        (clk_200m),
    .rst_n      (rst_n),
    .start      (win_ready_int),  // Pulse: begin reading back accumulator
    .rd_ping    (rd_ping),
    .rd_addr    (mac_rd_addr),
    .rd_data    (mac_rd_data),
    .win_spikes (win_spikes),
    .done       ()
);

// ================================================================
// 3. PIPELINE SEQUENCER
// ================================================================
reg [1:0] seq_state;
localparam SEQ_IDLE = 2'd0;
localparam SEQ_ARM  = 2'd1;
localparam SEQ_RUN  = 2'd2;
localparam SEQ_DONE = 2'd3;

always @(posedge clk_200m or negedge rst_n) begin
    if (!rst_n) begin
        seq_state <= SEQ_IDLE;
        mac_start <= 1'b0;
    end else begin
        mac_start <= 1'b0;
        case (seq_state)
            SEQ_IDLE: if (win_ready_int) begin
                mac_start <= 1'b1;
                seq_state <= SEQ_ARM;
            end
            SEQ_ARM:  seq_state <= SEQ_RUN;
            SEQ_RUN:  if (mac_done)      seq_state <= SEQ_DONE;
            SEQ_DONE: if (ol_result_valid) seq_state <= SEQ_IDLE;
            default:  seq_state <= SEQ_IDLE;
        endcase
    end
end

// ================================================================
// 4. BRAM ARBITER
// ================================================================
bram_arbiter #(
    .ADDR_WIDTH(14),
    .DATA_WIDTH(16)
) u_bram_arb (
    .clk        (clk_200m),
    .rst_n      (rst_n),
    .mac_req    (mac_bram_req),
    .mac_grant  (mac_bram_grant),
    .mac_done   (mac_bram_done),
    .mac_addr   (mac_bram_addr_int),
    .mac_din    (mac_bram_din_int),
    .mac_we     (mac_bram_we_int),
    .mac_dout   (mac_bram_dout_int),
    .bptt_req   (bptt_bram_req),
    .bptt_grant (bptt_bram_grant),
    .bptt_done  (bptt_bram_done),
    .bptt_addr  (bptt_bram_addr),
    .bptt_din   (bptt_bram_din),
    .bptt_we    (bptt_bram_we),
    .bptt_dout  (bptt_bram_dout),
    .wupd_req   (wupd_bram_req),
    .wupd_grant (wupd_bram_grant),
    .wupd_done  (wupd_bram_done),
    .wupd_addr  (wupd_bram_addr),
    .wupd_din   (wupd_bram_din),
    .wupd_we    (wupd_bram_we),
    .wupd_dout  (wupd_bram_dout),
    .host_req   (host_bram_req),
    .host_grant (host_bram_grant),
    .host_done  (host_bram_done),
    .host_addr  (host_bram_addr),
    .host_din   (host_bram_din),
    .host_we    (host_bram_we),
    .host_dout  (host_bram_dout),
    .bram_addr  (bram_bank3_addr),
    .bram_din   (bram_bank3_din),
    .bram_dout  (bram_bank3_dout),
    .bram_we    (bram_bank3_we),
    .bram_en    (bram_bank3_en)
);

// ================================================================
// 5. MAC ENGINE (PARALLEL)
// ================================================================
mac_engine_parallel #(
    .NH(NH), .NI(NI), .NO(NO), .T(T),
    .W_IN_BASE (14'h0000),
    .W_REC_BASE(14'h0800),
    .W_OUT_BASE(14'h4800)
) u_mac (
    .clk            (clk_200m),
    .rst_n          (rst_n),
    .mac_start      (mac_start),
    .mac_done       (mac_done),
    .mac_bram_req   (mac_bram_req),
    .mac_bram_grant (mac_bram_grant),
    .mac_bram_addr  (mac_bram_addr_int),
    .mac_bram_din   (mac_bram_din_int),
    .mac_bram_we    (mac_bram_we_int),
    .mac_bram_dout  (mac_bram_dout_int),
    .win_spikes     (win_spikes),
    .lif_acc        (lif_acc),
    .lif_idx        (lif_idx),
    .lif_wen        (lif_wen),
    .lif_capture    (lif_capture),
    .lif_spikes     (lif_spikes),
    .score_out      (score_out),
    .score_valid    (score_valid)
);

// ================================================================
// 6. LIF ARRAY (FIXED – see lif_array_bram_fixed.v)
// ================================================================
lif_array_bram_fixed #(
    .NH(NH), .ALPHA(16'h00E0), .THETA(16'h0100)
) u_lif (
    .clk            (clk_200m),
    .rst_n          (rst_n),
    .clear_state    (1'b0),
    .lif_acc        (lif_acc),
    .lif_idx        (lif_idx),
    .lif_wen        (lif_wen),
    .lif_capture    (lif_capture),
    .lif_spikes     (lif_spikes),
    .capture_done   (capture_done),
    .vm_addr        (bram_bank2_addr),
    .vm_din         (bram_bank2_din),
    .vm_dout        (bram_bank2_dout),
    .vm_we          (bram_bank2_we),
    .vm_en          (bram_bank2_en)
);

// ================================================================
// 7. OUTPUT LAYER (with built-in overlap voter)
// ================================================================
output_layer #(
    .NO(NO), .NH(NH)
) u_output (
    .clk            (clk_200m),
    .rst_n          (rst_n),
    .score_out      (score_out),
    .score_valid    (score_valid),
    .cmd_id         (ol_cmd_id),
    .confidence     (ol_confidence),
    .result_valid   (ol_result_valid),
    .combined_scores()
);

// Output assignments
assign cmd_id       = ol_cmd_id;
assign result_valid = ol_result_valid;
assign confidence   = ol_confidence[15:8];   // Q8.8 upper byte → Q8.0 percentage

// ================================================================
// 8. BRAM IP INSTANTIATIONS
// ================================================================

// BRAM Bank 2 – Neuron V_m state (512 × 16-bit, RAMB18E2 on ZCU104)
bram_bank2_vm u_bram_vm (
    .clka  (clk_200m),
    .ena   (bram_bank2_en),
    .wea   (bram_bank2_we),
    .addra (bram_bank2_addr),
    .dina  (bram_bank2_din),
    .douta (bram_bank2_dout)
);

// BRAM Bank 3 – Weights (16384 × 16-bit, RAMB36E2 on ZCU104)
bram_bank3_weights u_bram_weights (
    .clka  (clk_200m),
    .ena   (bram_bank3_en),
    .wea   (bram_bank3_we),
    .addra (bram_bank3_addr),
    .dina  (bram_bank3_din),
    .douta (bram_bank3_dout)
);

endmodule
