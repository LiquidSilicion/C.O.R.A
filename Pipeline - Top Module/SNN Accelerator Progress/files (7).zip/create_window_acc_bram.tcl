# =============================================================================
# create_window_acc_bram.tcl
# Run in Vivado Tcl Console:  source create_window_acc_bram.tcl
#
# ─── CHANGE vs previous version ──────────────────────────────────────────────
#  module_name changed from  window_acc_bram  →  window_acc
#
#  The s10_window_accumulator.v instantiates the BRAM as:
#    window_acc u_win_bram ( ... )
#  so the IP module name must also be  window_acc.
#
#  If the names don't match xsim cannot find the module at all, and Vivado
#  synthesis maps to the wrong (old) IP — causing the "cannot find port douta /
#  web / dinb" errors because it was finding the stale window_acc_bram IP which
#  was generated with Always_Enabled (hidden ports).
#
# ─── Enable_A / Enable_B ─────────────────────────────────────────────────────
#  Both kept as  Use_ENA_Pin / Use_ENB_Pin  (not Always_Enabled).
#  This keeps all six Port-B ports (clkb enb web addrb dinb doutb) visible
#  so snn_accelerator_top and s10_window_accumulator can connect them.
#
# ─── Spec (unchanged) ────────────────────────────────────────────────────────
#  True Dual Port, 8-bit × 2048 words
#  Port A : WRITE_FIRST  (accumulator FSM read-modify-write)
#  Port B : READ_FIRST   (spike_readback read-only)
#  Latency : 1 cycle (no output register)
#  Reset   : none
# =============================================================================

# ── If the old IP exists, remove it first ────────────────────────────────────
# In Vivado GUI: Sources → right-click window_acc_bram.xci → Remove File from Project
# Or in Tcl (uncomment if needed):
# if {[llength [get_ips window_acc_bram]] > 0} {
#     export_ip_user_files -of_objects [get_ips window_acc_bram] -no_script -reset -force -quiet
#     delete_ip_run [get_runs window_acc_bram_synth_1]
#     remove_files  [get_files window_acc_bram.xci]
# }

create_ip -name blk_mem_gen \
          -vendor xilinx.com \
          -library ip \
          -version 8.4 \
          -module_name window_acc

set_property -dict [list \
    CONFIG.Component_Name       {window_acc}             \
    CONFIG.Memory_Type          {True_Dual_Port_RAM}     \
    CONFIG.Write_Width_A        {8}                      \
    CONFIG.Write_Depth_A        {2048}                   \
    CONFIG.Read_Width_A         {8}                      \
    CONFIG.Write_Width_B        {8}                      \
    CONFIG.Write_Depth_B        {2048}                   \
    CONFIG.Read_Width_B         {8}                      \
    CONFIG.Operating_Mode_A     {WRITE_FIRST}            \
    CONFIG.Operating_Mode_B     {READ_FIRST}             \
    CONFIG.Enable_A             {Use_ENA_Pin}            \
    CONFIG.Enable_B             {Use_ENB_Pin}            \
    CONFIG.Register_PortA_Output_of_Memory_Primitives {false} \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Use_RSTA_Pin         {false}                  \
    CONFIG.Use_RSTB_Pin         {false}                  \
    CONFIG.Fill_Remaining_Memory_Locations {true}        \
    CONFIG.Remaining_Memory_Locations {0}                \
] [get_ips window_acc]

generate_target all [get_files window_acc.xci]

puts "✓ window_acc created"
puts "  True Dual Port, 8-bit × 2048 words, 1 × RAMB18E2"
puts "  module_name = window_acc  (matches instance in s10_window_accumulator.v)"
puts "  ena/enb pins EXPOSED  (Use_ENA_Pin / Use_ENB_Pin)"
puts ""
puts "Port A (WRITE_FIRST): clka ena wea addra[10:0] dina[7:0] douta[7:0]"
puts "Port B (READ_FIRST) : clkb enb web addrb[10:0] dinb[7:0] doutb[7:0]"
