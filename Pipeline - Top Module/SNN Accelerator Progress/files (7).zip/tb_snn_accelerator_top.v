`timescale 1ns / 1ps
// =============================================================================
// tb_snn_accelerator_top.v  —  Testbench for snn_accelerator_top
// Target : Vivado xsim  (ZCU104 / XCZU7EV @ 200 MHz)
//
// KEY OVERRIDES FOR SIMULATION:
//   WINDOW_CYCLES = 200   instead of 10_000_000
//
// IMPORTANT — DO NOT source create_brams.tcl from inside this file.
//   Run that script ONCE from the Vivado Tcl Console before simulating:
//     source create_brams.tcl
//     source create_window_acc_bram.tcl
//   Then add window_acc.v + bram_sim_stubs.v as Simulation Sources only.
//
// SIMULATION RUN TIME:
//   Set to at least 30,000 ns in:
//   Simulation Settings → xsim.simulate.runtime = 30000ns
// =============================================================================

module tb_snn_accelerator_top;

// ─── Clock & sim parameters ──────────────────────────────────────────────────
localparam real    CLK_HALF       = 2.5;          // 200 MHz → 5 ns period
localparam integer WIN_CYCLES     = 200;          // OVERRIDDEN (real=10_000_000)
localparam integer WIN_TIMEOUT    = WIN_CYCLES * 3;   //  600 cycles
localparam integer RESULT_TIMEOUT = WIN_CYCLES * 20;  // 4000 cycles

// ─── DUT ports ───────────────────────────────────────────────────────────────
reg         clk_200m;
reg         rst_n;
reg         aer_valid;
reg  [23:0] aer_data;
reg         speech_valid;
wire        window_ready;
wire        result_valid;
wire [3:0]  cmd_id;
wire [7:0]  confidence;

// ─── Testbench counters (visible in waveform) ─────────────────────────────
integer cycle_cnt;
integer win_cnt;
integer result_cnt;

// ─── Clock generation ────────────────────────────────────────────────────────
initial clk_200m = 0;
always #(CLK_HALF) clk_200m = ~clk_200m;

always @(posedge clk_200m) begin
    if (!rst_n) cycle_cnt <= 0;
    else        cycle_cnt <= cycle_cnt + 1;
end

// ─── DUT ─────────────────────────────────────────────────────────────────────
snn_accelerator_top dut (
    .clk_200m    (clk_200m),
    .rst_n       (rst_n),
    .aer_valid   (aer_valid),
    .aer_data    (aer_data),
    .speech_valid(speech_valid),
    .window_ready(window_ready),
    .result_valid(result_valid),
    .cmd_id      (cmd_id),
    .confidence  (confidence)
);

defparam dut.u_win_accum.WINDOW_CYCLES = WIN_CYCLES;

// ─── Waveform ────────────────────────────────────────────────────────────────
initial begin
    $dumpfile("tb_snn_accelerator_top.vcd");
    $dumpvars(0, tb_snn_accelerator_top);
end

// ─── Watchdog ────────────────────────────────────────────────────────────────
initial begin
    #30_000;
    $display("[WATCHDOG] 30,000 ns elapsed — forcing finish.");
    $finish;
end

// =============================================================================
// MAIN TEST SEQUENCE
// =============================================================================
initial begin
    rst_n        = 0;
    aer_valid    = 0;
    aer_data     = 24'd0;
    speech_valid = 0;
    win_cnt      = 0;
    result_cnt   = 0;

    $display("============================================================");
    $display("  SNN Accelerator Testbench - ZCU104 @ 200 MHz");
    $display("  NH=128  NI=16  NO=10  T=50");
    $display("  WINDOW_CYCLES=%0d  WIN_TIMEOUT=%0d  RESULT_TIMEOUT=%0d",
             WIN_CYCLES, WIN_TIMEOUT, RESULT_TIMEOUT);
    $display("  overlap_voter: PAIRED mode (result every 2 windows)");
    $display("============================================================");

    // ── TEST 1: Reset ─────────────────────────────────────────────────────────
    $display("[TEST 1] Reset and startup");
    repeat(10) @(posedge clk_200m);
    rst_n = 1;
    repeat(5)  @(posedge clk_200m);

    chk_no_x("window_ready", window_ready, 1'b0);
    chk_no_x("result_valid",  result_valid, 1'b0);
    chk_no_x("cmd_id[0]",     cmd_id[0],    1'b0);
    chk_no_x("confidence[0]", confidence[0],1'b0);
    $display("[TEST 1] DONE");

    // ── TEST 2: Window 1 ──────────────────────────────────────────────────────
    $display("[TEST 2] Window 1 — inject spikes, expect window_ready");
    $display("         result_valid NOT expected (voter needs 2 windows)");

    speech_valid = 1;
    inject_spikes(20);
    wait_sig("window_ready", window_ready, WIN_TIMEOUT);
    @(posedge clk_200m);
    win_cnt = win_cnt + 1;
    $display("[INFO]  win_cnt = %0d", win_cnt);
    $display("[TEST 2] DONE");

    // ── TEST 3: Window 2 + result_valid ───────────────────────────────────────
    $display("[TEST 3] Window 2 — expect result_valid from overlap_voter");

    inject_spikes(20);
    wait_sig("window_ready (2nd)", window_ready, WIN_TIMEOUT);
    @(posedge clk_200m);
    win_cnt = win_cnt + 1;
    $display("[INFO]  win_cnt = %0d", win_cnt);

    wait_sig("result_valid", result_valid, RESULT_TIMEOUT);
    if (result_valid) begin
        result_cnt = result_cnt + 1;
        $display("[PASS]  result_valid: cmd_id=%0d  confidence=0x%02h",
                 cmd_id, confidence);
    end else begin
        $display("[WARN]  result_valid did NOT fire within %0d cycles", RESULT_TIMEOUT);
        $display("        Possible causes:");
        $display("          1. mac_engine never asserts mac_done");
        $display("          2. output_layer never asserts score_valid");
        $display("          3. overlap_voter waiting for 2nd window score");
        $display("        Check those signals in waveform.");
    end
    $display("[TEST 3] DONE");

    // ── TEST 4: cmd_id range ──────────────────────────────────────────────────
    $display("[TEST 4] Sanity — cmd_id in range 0..9");
    if (result_cnt > 0) begin
        if (cmd_id <= 4'd9)
            $display("[PASS]  cmd_id = %0d (0..9 OK)", cmd_id);
        else
            $display("[FAIL]  cmd_id = %0d  OUT OF RANGE", cmd_id);
    end else
        $display("[SKIP]  No result_valid — cannot check cmd_id");

    // ── Finish ────────────────────────────────────────────────────────────────
    repeat(20) @(posedge clk_200m);
    speech_valid = 0;
    repeat(10) @(posedge clk_200m);

    $display("============================================================");
    $display("  Simulation complete.");
    $display("  Windows : %0d  |  Results : %0d", win_cnt, result_cnt);
    $display("============================================================");
    $finish;
end

// =============================================================================
// TASKS
// =============================================================================

// Inject n AER spikes with random ch (0..7) and timestamp (0..49999)
task inject_spikes;
    input integer n;
    integer k;
    reg [3:0]  rch;
    reg [15:0] rts;
    begin
        for (k = 0; k < n; k = k + 1) begin
            @(posedge clk_200m);
            rch       = $urandom_range(0, 7);
            rts       = $urandom_range(0, 49999);
            aer_valid = 1;
            aer_data  = {rch, 4'b0000, rts};  // [23:20]=ch, [19:4]=ts, [3:0]=0
            @(posedge clk_200m);
            aer_valid = 0;
            aer_data  = 24'd0;
            repeat(3) @(posedge clk_200m);
        end
    end
endtask

// Wait up to 'timeout' cycles for sig to go high
task wait_sig;
    input [255:0] label;
    input         sig;
    input integer timeout;
    integer t;
    begin
        t = 0;
        while (!sig && t < timeout) begin
            @(posedge clk_200m);
            t = t + 1;
        end
        if (sig)
            $display("[PASS]  %-24s asserted after %0d cycles", label, t);
        else
            $display("[WARN]  %-24s NOT seen in %0d cycles", label, timeout);
    end
endtask

// Check 1-bit signal for X/Z
task chk_no_x;
    input [255:0] label;
    input         sig;
    input         expected;
    begin
        if (sig === 1'bx || sig === 1'bz)
            $display("[FAIL]  %-20s = X/Z  (expected %b)", label, expected);
        else if (sig !== expected)
            $display("[WARN]  %-20s = %b    (expected %b)", label, sig, expected);
        else
            $display("[PASS]  %-20s = %b    (no X)", label, sig);
    end
endtask

endmodule
