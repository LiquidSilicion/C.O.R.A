`timescale 1ns / 1ps
// =============================================================================
// window_acc — BEHAVIORAL SIMULATION STUB
// =============================================================================
// Module name : window_acc
//   Matches the IP module_name set in create_window_acc_bram.tcl:
//     -module_name window_acc
//
// This replaces the Vivado Block Memory Generator IP during xsim elaboration.
// Add to Vivado as a SIMULATION-ONLY source (not Design Sources).
//
// Spec:
//   True Dual Port RAM, 8-bit × 2048 words
//   Port A : WRITE_FIRST  (read-modify-write by accumulator FSM)
//   Port B : READ_FIRST   (read-only by spike_readback)
//   Latency : 1 clock cycle, no output register
//   Enable pins : EXPOSED (Use_ENA_Pin / Use_ENB_Pin)
//     — this is the root cause of the original errors:
//       [VRFC 10-3180] cannot find port 'douta' / 'web' / 'dinb'
//     With Always_Enabled those ports are hidden by Vivado's wrapper.
//     With Use_ENA_Pin / Use_ENB_Pin they are visible and this stub matches.
// =============================================================================

module window_acc (
    // Port A — write by accumulator FSM
    input  wire        clka,
    input  wire        ena,
    input  wire        wea,
    input  wire [10:0] addra,
    input  wire [7:0]  dina,
    output reg  [7:0]  douta,   // WRITE_FIRST: forwards dina on write cycle

    // Port B — read by spike_readback
    input  wire        clkb,
    input  wire        enb,
    input  wire        web,     // tied 1'b0 in the design (read-only)
    input  wire [10:0] addrb,
    input  wire [7:0]  dinb,    // tied 8'd0 in the design
    output reg  [7:0]  doutb
);

    reg [7:0] mem [0:2047];

    integer idx;
    initial begin
        for (idx = 0; idx < 2048; idx = idx + 1)
            mem[idx] = 8'h00;
        douta = 8'h00;
        doutb = 8'h00;
    end

    // ── Port A : WRITE_FIRST ─────────────────────────────────────────────────
    // On a write cycle the new data is forwarded to douta in the same cycle,
    // allowing the read-modify-write FSM to see the written value immediately.
    always @(posedge clka) begin
        if (ena) begin
            if (wea) begin
                mem[addra] <= dina;
                douta      <= dina;       // WRITE_FIRST forwarding
            end else begin
                douta      <= mem[addra]; // normal read
            end
        end
    end

    // ── Port B : READ_FIRST ──────────────────────────────────────────────────
    // Old data appears on doutb before any write takes effect.
    // Port B is read-only in this design (web always 0).
    always @(posedge clkb) begin
        if (enb) begin
            doutb <= mem[addrb];          // output old data first (READ_FIRST)
            if (web)
                mem[addrb] <= dinb;
        end
    end

endmodule
