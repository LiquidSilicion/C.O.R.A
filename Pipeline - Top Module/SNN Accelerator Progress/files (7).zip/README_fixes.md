# SNN Accelerator — Bug Fixes & How to Apply Them

## Summary of the Three Root Causes

| # | Error | Root Cause | Fix |
|---|-------|------------|-----|
| 1 | `lif_vm_idx` double-driven | Old top had two `assign` statements driving the same wire | Already fixed in `snn_accelerator_top_final.v` (single driver at line 228) |
| 2 | `cannot find port 'enb'` on all BRAMs | IPs were generated with `Always_Enabled`, which hides the `ena`/`enb` pins | Two-part fix: regenerate IPs with updated TCL + add sim stubs |
| 3 | Cascading "module ignored" errors | xsim stops elaborating any module that references a broken submodule | Fix 1 & 2 eliminate all of these automatically |

---

## Files in This Package

```
snn_accelerator_top_final.v    — Top RTL (no changes needed, already correct)
s10_window_accumulator.v       — Stage 10 RTL (no changes needed)
create_brams.tcl               — Vivado TCL: regenerates bank_1_vm/s, bank_3_win/wrec/wout
create_window_acc_bram.tcl     — Vivado TCL: regenerates window_acc_bram
window_acc_bram.v              — *** NEW: behavioral sim stub for window_acc_bram ***
bram_sim_stubs.v               — *** NEW: behavioral sim stubs for all 5 bank_* IPs ***
```

---

## Step-by-Step Fix Instructions

### Step 1 — Delete the old broken BRAM IPs from your Vivado project

In Vivado **Sources** panel → **Design Sources**:
- Right-click `u_bram_weights.xci` → **Remove File from Project**
- Right-click `u_bram_vm.xci` → **Remove File from Project**
- If `window_acc_bram.xci` was generated with `Always_Enabled`, remove it too.

Then in the **Tcl Console**:
```tcl
reset_run synth_1
```

---

### Step 2 — Regenerate all BRAM IPs with the fixed TCL scripts

In Vivado **Tcl Console**, run both scripts:
```tcl
source create_brams.tcl
source create_window_acc_bram.tcl
```

These scripts now use `Enable_A {Use_ENA_Pin}` and `Enable_B {Use_ENB_Pin}` instead
of `{Always_Enabled}`. This exposes the `ena`/`enb` ports so that port connections
in `snn_bram_top.v` and `s10_window_accumulator.v` resolve correctly.

---

### Step 3 — Add the behavioral sim stubs as SIMULATION-ONLY sources

In Vivado, **Add Sources** → **Add or Create Simulation Sources**:
- Add `window_acc_bram.v`
- Add `bram_sim_stubs.v`

**CRITICAL:** Do NOT add these to Design Sources (synthesis). They must appear only
under **Simulation Sources** in the Sources panel. The real Vivado IPs from Step 2
are used for synthesis and implementation; the stubs are used only by xsim.

---

### Step 4 — For simulation: override WINDOW_CYCLES

The real window is 10,000,000 cycles (50 ms at 200 MHz). In your testbench,
override the parameter to something small so simulation completes quickly:

```verilog
s10_window_accumulator #(
    .WINDOW_CYCLES(200),    // <-- override for sim; default is 10_000_000
    .NI(16),
    .T(50)
) u_win_accum ( ... );
```

Or, if instantiating the full top:
```verilog
// Wrap snn_accelerator_top and force the sub-parameter via defparam (Verilog-2001):
defparam tb.u_dut.u_win_accum.WINDOW_CYCLES = 200;
```

---

### Step 5 — Verify in xsim

After the above steps, **Run Simulation**. You should see:
- Zero `[VRFC 10-3180] cannot find port` errors
- Zero `double-driven` errors
- Zero `module is ignored due to previous errors` messages

---

## Detailed Explanation of Each Bug

### Bug 1: Double-driven `lif_vm_idx`

In an earlier version of `snn_accelerator_top_final.v`, the wire `lif_vm_idx` was
driven by two separate `assign` statements:

```verilog
// OLD (broken) — two drivers:
assign lif_vm_idx = lif_idx;                    // line 281 — from MAC
wire [6:0] lif_vm_idx = lif_vm_addr_full[6:0];  // line 313 — from LIF
```

The current file is already fixed — there is exactly one driver:
```verilog
// CORRECT (current file):
wire [6:0] lif_vm_idx = lif_vm_addr_full[6:0];  // line 228, single declaration
```
No change needed to the RTL file.

---

### Bug 2: BRAM ports hidden by `Always_Enabled`

When Vivado Block Memory Generator is configured with `Enable_A {Always_Enabled}`,
it **removes the `ena` port entirely** from the generated wrapper. Any module that
tries to connect `.ena(...)` then fails with:

```
[VRFC 10-3180] cannot find port 'ena' on this module [window_acc_bram]
[VRFC 10-3180] cannot find port 'enb' on this module [window_acc_bram]
```

The fix is to use `Use_ENA_Pin` / `Use_ENB_Pin`, which keeps the pins visible.
The updated TCL scripts do exactly this.

The behavioral stubs (`window_acc_bram.v`, `bram_sim_stubs.v`) also expose all
the pins so xsim can elaborate the design immediately, without waiting for Vivado
to regenerate the IP synthesis products.

---

### Bug 3: Cascading "module ignored" errors

xsim elaboration is sequential. When it encounters a fatal port-binding error on
`window_acc_bram`, it marks that instance as broken and then refuses to elaborate
any module that instantiates the broken one. This cascades upward through the
hierarchy, producing lines like:

```
Module 's10_window_accumulator' ignored due to previous errors.
Module 'snn_accelerator_top' ignored due to previous errors.
```

These are all symptoms of Bug 2. Fix Bug 2 and they all disappear.

---

## Port Reference for Behavioral Stubs

### `window_acc_bram` (True Dual Port, 8b × 2048)
| Port | Direction | Width | Description |
|------|-----------|-------|-------------|
| clka | input | 1 | Port A clock |
| ena  | input | 1 | Port A enable (EXPOSED — was the bug) |
| wea  | input | 1 | Port A write enable |
| addra| input | 11 | Port A address |
| dina | input | 8  | Port A write data |
| douta| output | 8 | Port A read data (WRITE_FIRST) |
| clkb | input | 1  | Port B clock |
| enb  | input | 1  | Port B enable (EXPOSED — was the bug) |
| web  | input | 1  | Port B write enable (tied 0 in design) |
| addrb| input | 11 | Port B address (from spike_readback) |
| dinb | input | 8  | Port B write data (tied 0 in design) |
| doutb| output | 8 | Port B read data → mac_rd_data |

### `bank_1_vm` (Simple Dual Port, 16b × 1024)
Addr width: 10 bits. Data width: 16 bits.

### `bank_1_s` (Simple Dual Port, 128b × 512)
Addr width: 9 bits. Data width: 128 bits.

### `bank_3_win` (Simple Dual Port, 16b × 2048)
Addr width: 11 bits. Data width: 16 bits.

### `bank_3_wrec` (Simple Dual Port, 16b × 16384)
Addr width: 14 bits. Data width: 16 bits.

### `bank_3_wout` (Simple Dual Port, 16b × 2048)
Addr width: 11 bits. Data width: 16 bits.
