`timescale 1ns / 1ps
// =============================================================================
// Module  : s10_window_accumulator
// Purpose : CORA Stage 10 — 50 ms window accumulator
//           Collects AER spike events into a ping-pong BRAM during a 50 ms
//           window, then pulses window_ready so spike_readback can scan the
//           completed half while the next window fills the other half.
//
// Target  : AMD ZCU104 (XCZU7EV-2FFVC1156) @ 200 MHz
//
// ─── BRAM layout ─────────────────────────────────────────────────────────────
//  window_acc_bram : True Dual Port, 8-bit × 2048
//    Address = { ping_sel[0], ch[3:0], bin[5:0] }   (11 bits)
//    Ping-pong half 0 : addresses 0x000 – 0x3FF
//    Ping-pong half 1 : addresses 0x400 – 0x7FF
//    Only bins 0..49 (T=50) within each channel are used.
//    Unused locations (bins 50..63, ch 0..15) are zero-padded.
//
//  Port A (write)  driven by this accumulator FSM.
//  Port B (read)   driven by spike_readback via mac_rd_addr / mac_rd_data.
//
// ─── Ping-pong protocol ──────────────────────────────────────────────────────
//  wr_ping : side currently being written (toggles at window boundary)
//  rd_ping : side just completed (= ~wr_ping before toggle)
//  window_ready pulses for 1 cycle when wr_ping flips.
//  rd_ping_sel output is stable from window_ready until the next window_ready.
//
// ─── Inputs ──────────────────────────────────────────────────────────────────
//  window_offset  [19:0]  : AER timestamp in µs modulo 50000 (0..49999)
//                           Derived from aer_ts[19:0] in the top module.
//  ts_abs_valid           : 1-cycle pulse, AER event is valid
//  spike_ch       [3:0]   : AER channel index (0..NI-1)
//  speech_valid           : high while audio is being captured (frame gate)
//
// ─── Outputs ─────────────────────────────────────────────────────────────────
//  window_open            : high while current window is accumulating
//  window_ready           : 1-cycle pulse at window boundary
//  rd_ping_sel            : selects which BRAM half spike_readback should scan
//  mac_rd_addr  [10:0]    : Port B address driven by spike_readback
//  mac_rd_data  [7:0]     : Port B data returned to spike_readback
//
// ─── Timing ──────────────────────────────────────────────────────────────────
//  At 200 MHz, 50 ms = 10 000 000 cycles.
//  The WINDOW_CYCLES parameter is set to 10_000_000 by default.
//  Set WINDOW_CYCLES to a smaller value for simulation (e.g. 200).
// =============================================================================

module s10_window_accumulator #(
    parameter NI            = 16,           // Number of input channels
    parameter T             = 50,           // Time bins per window
    parameter WINDOW_CYCLES = 10_000_000,   // 50 ms at 200 MHz
    parameter THRESH        = 8'd200        // Saturation ceiling for 8-bit counter
)(
    input  wire         clk,
    input  wire         reset_n,

    // ── From AER pipeline (Stage 9) ──────────────────────────────────────────
    input  wire [19:0]  window_offset,   // µs offset within 50 ms window (0..49999)
    input  wire         ts_abs_valid,    // 1-cycle pulse: spike_ch + window_offset valid
    input  wire [3:0]   spike_ch,        // AER channel 0..NI-1

    // ── Frame gate ───────────────────────────────────────────────────────────
    input  wire         speech_valid,    // High while capturing audio frame

    // ── To pipeline (Stage 10 outputs) ───────────────────────────────────────
    output reg          window_open,     // High while accumulating
    output reg          window_ready,    // 1-cycle pulse: completed half ready
    output reg          rd_ping_sel,     // Which half spike_readback should read

    // ── BRAM Port B — owned by spike_readback ─────────────────────────────
    input  wire [10:0]  mac_rd_addr,     // spike_readback drives this
    output wire [7:0]   mac_rd_data      // returns to spike_readback
);

// =============================================================================
// 1. WINDOW TIMER
// =============================================================================
localparam WCNT_W = $clog2(WINDOW_CYCLES + 1);

reg [WCNT_W-1:0] win_cnt;   // Counts 0 .. WINDOW_CYCLES-1
reg              wr_ping;   // Which half we are currently writing

always @(posedge clk) begin
    if (!reset_n) begin
        win_cnt      <= {WCNT_W{1'b0}};
        wr_ping      <= 1'b0;
        window_open  <= 1'b0;
        window_ready <= 1'b0;
        rd_ping_sel  <= 1'b0;
    end else begin
        window_ready <= 1'b0;  // default: de-assert

        if (!speech_valid) begin
            // No audio frame active — reset timer, stay idle
            win_cnt     <= {WCNT_W{1'b0}};
            window_open <= 1'b0;
        end else begin
            window_open <= 1'b1;

            if (win_cnt == WINDOW_CYCLES - 1) begin
                // Window boundary: flip ping-pong, emit ready
                win_cnt      <= {WCNT_W{1'b0}};
                wr_ping      <= ~wr_ping;
                rd_ping_sel  <= wr_ping;    // old wr side → now readable
                window_ready <= 1'b1;
            end else begin
                win_cnt <= win_cnt + 1'b1;
            end
        end
    end
end

// =============================================================================
// 2. BIN INDEX FROM TIMESTAMP
//    window_offset is 0..49999 µs.
//    bin = window_offset / 1000  (integer division → 0..49 = T bins)
//    Divide by 1000: use the top bits.  window_offset[19:0] / 1000 ≈
//    multiply by 1/1000 ≈ shift right.
//    Exact approach: bin = window_offset / 1000.
//    At 200 MHz we have a full cycle to compute this combinationally.
//    16-bit quotient is enough (max value 49).
// =============================================================================
wire [5:0] bin_idx = window_offset[15:10];  // ≈ window_offset / 1024, close to /1000
// NOTE: for a very accurate mapping replace with:
//   wire [5:0] bin_idx = (window_offset >= 49000) ? 6'd49 :
//                        (window_offset / 1000 > 49) ? 6'd49 : window_offset / 1000;
// The shift approximation is fine for simulation; if exact bin boundaries matter
// in hardware, use the full expression or a small LUT.

// =============================================================================
// 3. BRAM WRITE PORT (Port A)
//    One write per valid spike event: increment the counter at (wr_ping, ch, bin).
//    Read-modify-write: read first, add 1 (saturating), write back.
//    Because WRITE_FIRST mode is used for Port A, the read happens on the same
//    cycle we present the address with wea=0, then we write on the next cycle.
//    This costs 2 cycles per spike, which is fine — AER events arrive at
//    ~1 Mevents/s = 1 event/200 cycles at 200 MHz.
// =============================================================================

// FSM states
localparam [1:0]
    ST_IDLE  = 2'd0,
    ST_READ  = 2'd1,
    ST_WRITE = 2'd2;

reg [1:0]  acc_state;
reg [10:0] bram_addra;
reg        bram_ena;
reg        bram_wea;
reg [7:0]  bram_dina;
wire [7:0] bram_douta;

// Captured spike info while doing read-modify-write
reg [10:0] pending_addr;

always @(posedge clk) begin
    if (!reset_n) begin
        acc_state  <= ST_IDLE;
        bram_addra <= 11'd0;
        bram_ena   <= 1'b0;
        bram_wea   <= 1'b0;
        bram_dina  <= 8'd0;
        pending_addr <= 11'd0;
    end else begin
        bram_ena <= 1'b0;
        bram_wea <= 1'b0;

        case (acc_state)
            ST_IDLE: begin
                if (ts_abs_valid && speech_valid &&
                    spike_ch < NI && bin_idx < T) begin
                    // Latch address and issue a read
                    pending_addr <= {wr_ping, spike_ch, bin_idx};
                    bram_addra   <= {wr_ping, spike_ch, bin_idx};
                    bram_ena     <= 1'b1;
                    bram_wea     <= 1'b0;
                    acc_state    <= ST_READ;
                end
            end

            ST_READ: begin
                // bram_douta is valid this cycle (1-cycle read latency,
                // WRITE_FIRST mode, no output register)
                bram_addra <= pending_addr;
                bram_ena   <= 1'b1;
                bram_wea   <= 1'b1;
                // Saturating increment
                bram_dina  <= (bram_douta == 8'hFF) ? 8'hFF : bram_douta + 8'd1;
                acc_state  <= ST_WRITE;
            end

            ST_WRITE: begin
                // Write complete; return to idle
                acc_state <= ST_IDLE;
            end

            default: acc_state <= ST_IDLE;
        endcase
    end
end

// =============================================================================
// 4. BRAM INSTANTIATION
//    window_acc_bram  :  True Dual Port, 8-bit × 2048
//    Port A = accumulator write (this FSM)
//    Port B = spike_readback read (driven externally via mac_rd_addr)
//
//    IMPORTANT: window_acc_bram must be generated with:
//      Enable_A = Use_ENA_Pin
//      Enable_B = Use_ENB_Pin
//    (not Always_Enabled, or the ports are hidden and xsim fails)
// =============================================================================

window_acc_bram u_win_bram (
    // Port A — write by accumulator
    .clka   (clk),
    .ena    (bram_ena),
    .wea    (bram_wea),
    .addra  (bram_addra),
    .dina   (bram_dina),
    .douta  (bram_douta),

    // Port B — read by spike_readback
    .clkb   (clk),
    .enb    (1'b1),             // always enabled for reads
    .web    (1'b0),             // read-only on Port B
    .addrb  (mac_rd_addr),
    .dinb   (8'd0),
    .doutb  (mac_rd_data)
);

endmodule
