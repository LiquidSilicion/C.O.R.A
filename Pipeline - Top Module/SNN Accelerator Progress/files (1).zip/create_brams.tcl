# =============================================================================
# create_brams.tcl  —  Create all BRAM IPs for CORA SNN Inference
# Run in Vivado Tcl console:  source create_brams.tcl
# Target: AMD ZCU104 (XCZU7EV-2FFVC1156) @ 200 MHz
# =============================================================================

# ── Bank 1a: V_m  16b × 1024  1 × RAMB18E2 ──────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name bank_1_vm
set_property -dict {
    CONFIG.Memory_Type                              Simple_Dual_Port_RAM
    CONFIG.Write_Width_A                            16
    CONFIG.Write_Depth_A                            1024
    CONFIG.Read_Width_A                             16
    CONFIG.Write_Width_B                            16
    CONFIG.Read_Width_B                             16
    CONFIG.Read_Depth_B                             1024
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
    CONFIG.Fill_Remaining_Memory_Locations          true
    CONFIG.Remaining_Memory_Locations               0
} [get_ips bank_1_vm]
generate_target all [get_files bank_1_vm.xci]
puts "bank_1_vm created  (16b x 1024, 1 x RAMB18E2, V_m)"

# ── Bank 1b: S[t]  128b × 512  4 × RAMB36E2 ─────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name bank_1_s
set_property -dict {
    CONFIG.Memory_Type                              Simple_Dual_Port_RAM
    CONFIG.Write_Width_A                            128
    CONFIG.Write_Depth_A                            512
    CONFIG.Read_Width_A                             128
    CONFIG.Write_Width_B                            128
    CONFIG.Read_Width_B                             128
    CONFIG.Read_Depth_B                             512
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
} [get_ips bank_1_s]
generate_target all [get_files bank_1_s.xci]
puts "bank_1_s  created  (128b x 512, 4 x RAMB36E2, S\[t\] spike history)"

# ── Bank 3a: W_in  16b × 2048  1 × RAMB36E2 ─────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name bank_3_win
set_property -dict {
    CONFIG.Memory_Type                              Simple_Dual_Port_RAM
    CONFIG.Write_Width_A                            16
    CONFIG.Write_Depth_A                            2048
    CONFIG.Read_Width_A                             16
    CONFIG.Write_Width_B                            16
    CONFIG.Read_Width_B                             16
    CONFIG.Read_Depth_B                             2048
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
    CONFIG.Load_Init_File                           false
} [get_ips bank_3_win]
# set_property CONFIG.Load_Init_File true  [get_ips bank_3_win]
# set_property CONFIG.Coe_File /path/to/w_in.coe [get_ips bank_3_win]
generate_target all [get_files bank_3_win.xci]
puts "bank_3_win created  (16b x 2048, 1 x RAMB36E2, W_in)"

# ── Bank 3b: W_rec  16b × 16384  8 × RAMB36E2 ───────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name bank_3_wrec
set_property -dict {
    CONFIG.Memory_Type                              Simple_Dual_Port_RAM
    CONFIG.Write_Width_A                            16
    CONFIG.Write_Depth_A                            16384
    CONFIG.Read_Width_A                             16
    CONFIG.Write_Width_B                            16
    CONFIG.Read_Width_B                             16
    CONFIG.Read_Depth_B                             16384
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
    CONFIG.Load_Init_File                           false
} [get_ips bank_3_wrec]
generate_target all [get_files bank_3_wrec.xci]
puts "bank_3_wrec created (16b x 16384, 8 x RAMB36E2, W_rec)"

# ── Bank 3c: W_out  16b × 2048  1 × RAMB36E2 ────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name bank_3_wout
set_property -dict {
    CONFIG.Memory_Type                              Simple_Dual_Port_RAM
    CONFIG.Write_Width_A                            16
    CONFIG.Write_Depth_A                            2048
    CONFIG.Read_Width_A                             16
    CONFIG.Write_Width_B                            16
    CONFIG.Read_Width_B                             16
    CONFIG.Read_Depth_B                             2048
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
    CONFIG.Load_Init_File                           false
} [get_ips bank_3_wout]
generate_target all [get_files bank_3_wout.xci]
puts "bank_3_wout created (16b x 2048, 1 x RAMB36E2, W_out, 1280 used)"

# ── window_acc_bram  8b × 2048  1 × RAMB18E2  TRUE DUAL PORT ─────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip -version 8.4 \
          -module_name window_acc_bram
set_property -dict {
    CONFIG.Memory_Type                              True_Dual_Port_RAM
    CONFIG.Write_Width_A                            8
    CONFIG.Write_Depth_A                            2048
    CONFIG.Read_Width_A                             8
    CONFIG.Write_Width_B                            8
    CONFIG.Write_Depth_B                            2048
    CONFIG.Read_Width_B                             8
    CONFIG.Operating_Mode_A                         WRITE_FIRST
    CONFIG.Operating_Mode_B                         READ_FIRST
    CONFIG.Enable_A                                 Always_Enabled
    CONFIG.Enable_B                                 Always_Enabled
    CONFIG.Register_PortA_Output_of_Memory_Primitives false
    CONFIG.Register_PortB_Output_of_Memory_Primitives false
    CONFIG.Use_RSTA_Pin                             false
    CONFIG.Use_RSTB_Pin                             false
    CONFIG.Fill_Remaining_Memory_Locations          true
    CONFIG.Remaining_Memory_Locations               0
} [get_ips window_acc_bram]
generate_target all [get_files window_acc_bram.xci]
puts "window_acc_bram created (8b x 2048, 1 x RAMB18E2, True Dual Port)"

puts ""
puts "====================================================="
puts " BRAM Summary"
puts "====================================================="
puts " bank_1_vm        1 x RAMB18E2   V_m    16b x 1024"
puts " bank_1_s         4 x RAMB36E2   S\[t\]  128b x 512"
puts " bank_3_win       1 x RAMB36E2   W_in   16b x 2048"
puts " bank_3_wrec      8 x RAMB36E2   W_rec  16b x 16384"
puts " bank_3_wout      1 x RAMB36E2   W_out  16b x 2048"
puts " window_acc_bram  1 x RAMB18E2   WinAcc  8b x 2048 (TDP)"
puts "-----------------------------------------------------"
puts " Total: 14 x RAMB36E2 + 2 x RAMB18E2"
puts " ZCU104 budget: 312 RAMB36E2, 624 RAMB18E2"
puts " Used: 4.5% + 0.3%"
puts "====================================================="
