# =============================================================================
# create_window_acc_bram.tcl
# Creates the window_acc_bram used INSIDE s10_window_accumulator.
# This is separate from snn_bram_top — it is instantiated directly in the
# window accumulator module, not through the unified BRAM wrapper.
#
# Spec:
#   Port A : Write port  — accumulator FSM (8-bit, synchronous write)
#   Port B : Read  port  — spike_readback module (8-bit, synchronous read)
#   Width  : 8 bits per word
#   Depth  : 2048 words  (2 × 16ch × 50bins, with 6 unused bins per half)
#   Mode   : True Dual Port  (simultaneous A-write + B-read in different cycles)
#   Latency: 1 cycle read latency (no output register)
#   Init   : All zeros (no pre-loaded data)
# =============================================================================

create_ip -name blk_mem_gen \
          -vendor xilinx.com \
          -library ip \
          -version 8.4 \
          -module_name window_acc_bram

set_property -dict [list \
    CONFIG.Memory_Type          {True_Dual_Port_RAM}    \
    CONFIG.Write_Width_A        {8}                     \
    CONFIG.Write_Depth_A        {2048}                  \
    CONFIG.Read_Width_A         {8}                     \
    CONFIG.Write_Width_B        {8}                     \
    CONFIG.Write_Depth_B        {2048}                  \
    CONFIG.Read_Width_B         {8}                     \
    CONFIG.Operating_Mode_A     {WRITE_FIRST}           \
    CONFIG.Operating_Mode_B     {READ_FIRST}            \
    CONFIG.Enable_A             {Always_Enabled}        \
    CONFIG.Enable_B             {Always_Enabled}        \
    CONFIG.Register_PortA_Output_of_Memory_Primitives {false} \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Use_RSTA_Pin         {false}                 \
    CONFIG.Use_RSTB_Pin         {false}                 \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {0}               \
] [get_ips window_acc_bram]

generate_target all [get_files window_acc_bram.xci]

puts "Created: window_acc_bram  (True Dual Port, 8-bit × 2048 words)"
puts "Physical: 1 × RAMB18E2"
puts ""
puts "Port mapping in s10_window_accumulator:"
puts "  .clka  -> clk         .clkb  -> clk"
puts "  .ena   -> bram_ena    .enb   -> 1'b1 (always enabled for reads)"
puts "  .wea   -> bram_wea    .web   -> 1'b0 (port B read-only)"
puts "  .addra -> bram_addra  .addrb -> mac_rd_addr"
puts "  .dina  -> bram_dina   .dinb  -> 8'd0"
puts "  .douta -> bram_douta  .doutb -> mac_rd_data"
