################################################################################
# create_brams.tcl
# Run in Vivado Tcl Console:  source create_brams.tcl
#
# Generates all BRAM IPs needed for the SNN accelerator inference pipeline.
#
# ──────────────────────────────────────────────────────────────────────────────
# BEFORE RUNNING THIS SCRIPT — DELETE THESE OLD IPs IF THEY EXIST:
#   u_bram_weights.xci   (was bram_bank3_weights — wrong depth, wrong addr width)
#   u_bram_vm.xci        (was bram_bank2_vm — superseded by bank_1_vm here)
#
# In Vivado:
#   Sources → Design Sources → right-click u_bram_weights → Remove File from Project
#   Sources → Design Sources → right-click u_bram_vm       → Remove File from Project
#
# If you already ran synthesis with the old IPs, also run:
#   reset_run synth_1
# before re-running synthesis with the new IPs.
# ──────────────────────────────────────────────────────────────────────────────
#
# IPs created by this script:
#   bank_1_vm    16-bit × 1024   RAMB18E2   LIF membrane potential V_m
#   bank_1_s    128-bit × 512    RAMB36E2×4 Spike history s[t] for W_rec pass
#   bank_3_win   16-bit × 2048   RAMB36E2   W_in weights
#   bank_3_wrec  16-bit × 16384  RAMB36E2×8 W_rec weights  (cascaded automatically)
#   bank_3_wout  16-bit × 2048   RAMB36E2   W_out weights (1280 of 2048 used)
#
# Physical BRAM usage on ZCU104 (XCZU7EV):
#   1×RAMB18E2 + 14×RAMB36E2  out of  624×RAMB18E2 + 312×RAMB36E2 available
#   = 0.16% RAMB18 + 4.5% RAMB36
#
# Address width note (FIX from previous version):
#   W_out base address = 0x4800 = 18432 → requires 15-bit address (bit 14 set).
#   All weight BRAMs now use addra[14:0] in snn_bram_top.
#   The old u_bram_weights used [13:0] = max 16383, so W_out was truncated.
################################################################################

set part "xczu7ev-ffvc1156-2-e"

# ──────────────────────────────────────────────────────────────────────────────
# BANK 1a : V_m — Neuron membrane potential
# 16-bit × 1024 words  (128 used, rest unused)
# Simple Dual Port: Port A write (LIF sweep), Port B read (LIF sweep readback)
# ──────────────────────────────────────────────────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip \
    -version 8.4 -module_name bank_1_vm

set_property -dict [list \
    CONFIG.Component_Name           {bank_1_vm}         \
    CONFIG.Memory_Type              {Simple_Dual_Port_RAM} \
    CONFIG.Write_Width_A            {16}                \
    CONFIG.Write_Depth_A            {1024}              \
    CONFIG.Read_Width_B             {16}                \
    CONFIG.Enable_A                 {Always_Enabled}    \
    CONFIG.Enable_B                 {Always_Enabled}    \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Load_Init_File           {false}             \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {0000}            \
] [get_ips bank_1_vm]

generate_target all [get_ips bank_1_vm]
puts "✓ bank_1_vm created  (16b × 1024 = 1 × RAMB18E2)"

# ──────────────────────────────────────────────────────────────────────────────
# BANK 1b : S[t] — Spike history (128-bit wide bus)
# 128-bit × 512 words
# Simple Dual Port: Port A write (MAC saves lif_spikes), Port B read (MAC loads s_prev)
# Vivado will cascade 4 × RAMB36E2 automatically for 128-bit width
# ──────────────────────────────────────────────────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip \
    -version 8.4 -module_name bank_1_s

set_property -dict [list \
    CONFIG.Component_Name           {bank_1_s}          \
    CONFIG.Memory_Type              {Simple_Dual_Port_RAM} \
    CONFIG.Write_Width_A            {128}               \
    CONFIG.Write_Depth_A            {512}               \
    CONFIG.Read_Width_B             {128}               \
    CONFIG.Enable_A                 {Always_Enabled}    \
    CONFIG.Enable_B                 {Always_Enabled}    \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Load_Init_File           {false}             \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {00000000000000000000000000000000} \
] [get_ips bank_1_s]

generate_target all [get_ips bank_1_s]
puts "✓ bank_1_s created   (128b × 512 = 4 × RAMB36E2)"

# ──────────────────────────────────────────────────────────────────────────────
# BANK 3a : W_in — Input weights
# 16-bit × 2048 words (NI=16 × NH=128 = 2048 exactly)
# Address range in snn_bram_top: 0x04000..0x047FF → local addr 0x000..0x7FF
# Read-only during inference; initialise from w_in.coe
# ──────────────────────────────────────────────────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip \
    -version 8.4 -module_name bank_3_win

set_property -dict [list \
    CONFIG.Component_Name           {bank_3_win}        \
    CONFIG.Memory_Type              {Simple_Dual_Port_RAM} \
    CONFIG.Write_Width_A            {16}                \
    CONFIG.Write_Depth_A            {2048}              \
    CONFIG.Read_Width_B             {16}                \
    CONFIG.Enable_A                 {Always_Enabled}    \
    CONFIG.Enable_B                 {Always_Enabled}    \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Load_Init_File           {false}             \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {0000}            \
] [get_ips bank_3_win]

# Uncomment once you have your w_in.coe:
# set_property CONFIG.Load_Init_File  {true}     [get_ips bank_3_win]
# set_property CONFIG.Coe_File        {/path/to/w_in.coe} [get_ips bank_3_win]

generate_target all [get_ips bank_3_win]
puts "✓ bank_3_win created  (16b × 2048 = 1 × RAMB36E2)"

# ──────────────────────────────────────────────────────────────────────────────
# BANK 3b : W_rec — Recurrent weights
# 16-bit × 16384 words (NH=128 × NH=128 = 16384)
# Vivado cascades 8 × RAMB36E2 automatically
# Address range in snn_bram_top: 0x04800..0x07FFF → local addr 0x0000..0x3FFF
# ──────────────────────────────────────────────────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip \
    -version 8.4 -module_name bank_3_wrec

set_property -dict [list \
    CONFIG.Component_Name           {bank_3_wrec}       \
    CONFIG.Memory_Type              {Simple_Dual_Port_RAM} \
    CONFIG.Write_Width_A            {16}                \
    CONFIG.Write_Depth_A            {16384}             \
    CONFIG.Read_Width_B             {16}                \
    CONFIG.Enable_A                 {Always_Enabled}    \
    CONFIG.Enable_B                 {Always_Enabled}    \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Load_Init_File           {false}             \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {0000}            \
] [get_ips bank_3_wrec]

# Uncomment once you have your w_rec.coe:
# set_property CONFIG.Load_Init_File  {true}      [get_ips bank_3_wrec]
# set_property CONFIG.Coe_File        {/path/to/w_rec.coe} [get_ips bank_3_wrec]

generate_target all [get_ips bank_3_wrec]
puts "✓ bank_3_wrec created (16b × 16384 = 8 × RAMB36E2)"

# ──────────────────────────────────────────────────────────────────────────────
# BANK 3c : W_out — Output weights
# 16-bit × 2048 words (next power-of-2 above 1280 = NH×NO = 128×10)
# Only addresses 0x000..0x4FF (1280) are used; rest is zero-padded
# Address range in snn_bram_top: 0x08000..0x084FF → local addr 0x000..0x4FF
#
# NOTE: This requires 15-bit address at the top level (bit 14 = 1 for 0x08000).
#       The old u_bram_weights.xci used [13:0] — that is the bug that caused
#       wrong classification output. This bank is configured correctly here.
# ──────────────────────────────────────────────────────────────────────────────
create_ip -name blk_mem_gen -vendor xilinx.com -library ip \
    -version 8.4 -module_name bank_3_wout

set_property -dict [list \
    CONFIG.Component_Name           {bank_3_wout}       \
    CONFIG.Memory_Type              {Simple_Dual_Port_RAM} \
    CONFIG.Write_Width_A            {16}                \
    CONFIG.Write_Depth_A            {2048}              \
    CONFIG.Read_Width_B             {16}                \
    CONFIG.Enable_A                 {Always_Enabled}    \
    CONFIG.Enable_B                 {Always_Enabled}    \
    CONFIG.Register_PortB_Output_of_Memory_Primitives {false} \
    CONFIG.Load_Init_File           {false}             \
    CONFIG.Fill_Remaining_Memory_Locations {true}       \
    CONFIG.Remaining_Memory_Locations {0000}            \
] [get_ips bank_3_wout]

# Uncomment once you have your w_out.coe:
# set_property CONFIG.Load_Init_File  {true}      [get_ips bank_3_wout]
# set_property CONFIG.Coe_File        {/path/to/w_out.coe} [get_ips bank_3_wout]

generate_target all [get_ips bank_3_wout]
puts "✓ bank_3_wout created (16b × 2048 = 1 × RAMB36E2)"

# ──────────────────────────────────────────────────────────────────────────────
puts ""
puts "=== ALL INFERENCE BRAMs CREATED ==="
puts "Physical BRAM usage:"
puts "  1  × RAMB18E2  (bank_1_vm)"
puts "  4  × RAMB36E2  (bank_1_s)"
puts "  1  × RAMB36E2  (bank_3_win)"
puts "  8  × RAMB36E2  (bank_3_wrec)"
puts "  1  × RAMB36E2  (bank_3_wout)"
puts "  ─────────────────────────────"
puts "  1  × RAMB18E2  +  14 × RAMB36E2  total"
puts "  (ZCU104 budget: 624 RAMB18E2 + 312 RAMB36E2)"
puts ""
puts "REMINDER: window_acc_bram (True Dual Port, 8b×2048) is a SEPARATE IP."
puts "Run create_window_acc_bram.tcl to generate it."
puts ""
puts "REMINDER: Delete u_bram_weights.xci and u_bram_vm.xci if they still"
puts "exist in your project — they conflict with the new IPs above."
# ──────────────────────────────────────────────────────────────────────────────
